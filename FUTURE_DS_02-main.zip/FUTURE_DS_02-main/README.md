# 📊 Facebook Ad Campaign Analysis Dashboard  

This repository contains a **Power BI dashboard** that provides insights into the performance of Facebook ad campaigns across different campaigns, demographics, and time periods. The dashboard highlights key marketing metrics such as impressions, clicks, CTR, amount spent, and conversions.  

---

## 📌 Features  

### **Cards for Key Metrics**  
- Total Impressions  
- Total Clicks  
- CTR (Click-Through Rate)  
- Total Amount Spent  
- Total Approved Conversions  

### **Visualizations**  
- **Bar Chart** – Clicks vs. Impressions by Campaign  
- **Stacked Area Chart** – CTR and Approved Conversion Trends over Time  
- **Pie Chart** – Spend Distribution by Gender  
- **Clustered Column Chart** – Campaign-wise Approved Conversions  
- **Table** – Age Group-wise Spend, Clicks, and Conversion Performance  
- **Line Chart** – Monthly Trend of Amount Spent vs. Conversions  

### **KPIs and Highlights**  
- Campaign **C-2** achieved the **highest approval conversions**.  
- CTR remained consistent across most campaigns with slight peaks mid-month.  
- **Male audience** received a higher ad spend allocation.  
- Best-performing **age group**: 30–34 years.  

---

## 🛠️ Tools Used  
- **Power BI** – For data modeling, DAX, and visualization  
- **CSV Dataset** – Campaign performance data  
- **DAX Measures** – For CTR and other calculations  

---

## 🚀 How to Use  
1. Download the `.pbix` file from this repository.  
2. Open it in **Power BI Desktop**.  
3. Load the dataset (`data.csv`).  
4. Interact with the filters (age, gender, campaign) to explore insights.  

---

## Dashboard Preview  





![task_2_dashboard](https://github.com/user-attachments/assets/e22277df-8d5a-4f35-9255-7cd897c15733)

---

## 🔮 Future Improvements  
- Integrate additional campaign data from Google Ads & LinkedIn Ads  
- Add **forecasting models** for conversions and ROI  
- Automate dataset refresh with Power BI Service  
